<?php
/**
 * 日志配置文件
 * User: shiyayun
 */
return [
    'DRIVE' => 'file',
    'OPTION' => [
        'PATH' => BASE.'/log/',
    ],
];