<?php
/**
 * 路由配置文件
 * User: shiyayun
 */
return [
    'CONTROLLER' => 'Index',
    'ACTION' => 'index',
];