<?php
/**
 * 数据库配置文件
 * User: shiyayun
 */
return [
    /*'DSN' => 'mysql:host=localhost;dbname=test',
    'USERNAME' => 'root',
    'PASSWD' => 'root',*/

    //medoo引擎数据库连接配置
    'database_type' => 'mysql',
    'database_name' => 'test',
    'server' => 'localhost',
    'username' => 'root',
    'password' => 'root',
    'charset' => 'utf8',
];