<?php
/**
 * Controller基类
 * User: shiyayun
 */
namespace core\lib;

class Controller extends \core\Core
{
    public $assign;
    public function assign($name,$value){
        $this->assign[$name] = $value;
    }

    public function display($file = '')
    {
        /*$file = ucfirst($file);//控制器名首字母转大写
        $file = APP.'/view/'.$file;
        if (is_file($file)){
            extract($this->assign);//将数组转换成变量和值的形式
            include $file;
        }*/
        try{
            //引入twig模板引擎
            //$file = ucfirst($file);//控制器名首字母转大写

            $fileArr = array_filter(explode('/', $file));

            $requestUriArr = array_filter(explode('/', ucfirst(trim($_SERVER['REQUEST_URI'], '/'))));
            //p($requestUriArr);
            if (count($requestUriArr) >= 2) {
                $requestUriArr = $requestUriArr;
            } elseif (count($requestUriArr) >= 1){
                $requestUriArr[1] = 'index';
            }else{
                $requestUriArr[0] = 'Index';
                $requestUriArr[1] = 'index';
            }

            if (count($fileArr) >= 2){
                $fileDir = $fileArr[0]?ucfirst($fileArr[0]):'Index';
                $fileHtml = $fileArr[1]?$fileArr[1]:'index.html';
            }elseif(count($fileArr) >= 1){
                $fileDir = $requestUriArr[0]?$requestUriArr[0]:'Index';
                $fileHtml = $fileArr[0]?$fileArr[0]:'index.html';
            }else{
                $fileDir = $requestUriArr[0]?$requestUriArr[0]:'Index';
                $fileHtml = $requestUriArr[1]?$requestUriArr[1].'.html':'index.html';
            }

            //$file = APP.'/view/'.$file;
            $file = APP.'/view/'.$fileDir.'/'.$fileHtml;

            if (is_file($file)){
                //extract($this->assign);//将数组转换成变量和值的形式
                //include $file;

                $loader = new \Twig_Loader_Filesystem(APP.'/view/'.$fileDir);
                $twig = new \Twig_Environment($loader, array(
                    'cache' => BASE.'/cache/twig',
                    'debug' => DEBUG,
                ));

                $template = $twig->load($fileHtml);
                $template->display($this->assign?$this->assign:'');
            }else{
                throw new \Exception("File not exist:".$file);
            }
        }catch (\Exception $e){
            p($e->getMessage());
        }

    }
}