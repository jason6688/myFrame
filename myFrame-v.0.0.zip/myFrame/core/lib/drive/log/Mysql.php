<?php
/**
 * 数据库
 * User: shiyayun
 */
namespace core\lib\drive\log;

class Mysql
{
    public function log($name){
        p($name);
    }
}